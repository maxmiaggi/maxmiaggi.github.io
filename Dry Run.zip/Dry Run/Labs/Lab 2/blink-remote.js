var five = require('johnny-five');
// var board = new five.Board({ port: "COM14" });
var board = new five.Board();

var PubNub = require("pubnub");
var pubnub = new PubNub({
    ssl          : true,  // <- enable TLS Tunneling over TCP
    publishKey   : "pub-c-",
    subscribeKey : "sub-c-"
});

var channel = 'led';
 
board.on('ready', function() {
  var led = new five.Led(13); // pin 13

  // pubnub.addListener({
  //   message: function(m) {
  //     if(m.message.blink == true) {
  //       led.blink(500);
  //     } else {
  //       led.stop();
  //       led.off();
  //     }
  //   }
  // });

  pubnub.subscribe({
    channels: [channel],
  });


});
